# Tic-Tac-Toe Tutorials

Hey Guys,

First part is #1 Printing Board: In this file you will see the code of the python program using which we can print our tic tac toe game board
Second, #2 Input to game: This file will contain the code to inputting the player number to a location specified by the user.
Third, #3 Checking Win: Here we will be checking for every winning situation in Tic Tac Toe game

I will be uploading files as soon as i upload video on my Youtube Channel : pypython 
link to my channel: https://www.youtube.com/channel/UCCI4DQohGipZcUThvY6cLeA

I request you to go  step by step with this tutorial and if you have any doubt with the code, ask me on the Youtubes' comment section
